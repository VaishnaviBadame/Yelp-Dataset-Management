﻿namespace Business
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.NameSearchText = new System.Windows.Forms.TextBox();
            this.Go_button = new System.Windows.Forms.Button();
            this.filter_lable = new System.Windows.Forms.Label();
            this.city_lable = new System.Windows.Forms.Label();
            this.stars_lable = new System.Windows.Forms.Label();
            this.categoris_lable = new System.Windows.Forms.Label();
            this.postal_code_lable = new System.Windows.Forms.Label();
            this.categories_text = new System.Windows.Forms.TextBox();
            this.city_text = new System.Windows.Forms.TextBox();
            this.postal_text = new System.Windows.Forms.TextBox();
            this.stars_combo = new System.Windows.Forms.ComboBox();
            this.reset_button = new System.Windows.Forms.Button();
            this.apply_button = new System.Windows.Forms.Button();
            this.result_grid = new System.Windows.Forms.DataGridView();
            this.result_lable = new System.Windows.Forms.Label();
            this.Query = new System.Windows.Forms.Label();
            this.QueryTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Top_Users = new System.Windows.Forms.Button();
            this.Go1button = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.postalText = new System.Windows.Forms.TextBox();
            this.Deliverlable = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.report_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.result_grid)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label1.Location = new System.Drawing.Point(12, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Search by Business Name";
            // 
            // NameSearchText
            // 
            this.NameSearchText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.NameSearchText.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.NameSearchText.Location = new System.Drawing.Point(16, 59);
            this.NameSearchText.Name = "NameSearchText";
            this.NameSearchText.Size = new System.Drawing.Size(281, 24);
            this.NameSearchText.TabIndex = 1;
            this.NameSearchText.Text = "Enter business name";
            this.NameSearchText.TextChanged += new System.EventHandler(this.NameSearchText_TextChanged);
            // 
            // Go_button
            // 
            this.Go_button.Location = new System.Drawing.Point(319, 59);
            this.Go_button.Name = "Go_button";
            this.Go_button.Size = new System.Drawing.Size(52, 34);
            this.Go_button.TabIndex = 2;
            this.Go_button.Text = "Go";
            this.Go_button.UseVisualStyleBackColor = true;
            this.Go_button.Click += new System.EventHandler(this.Go_button_Click);
            // 
            // filter_lable
            // 
            this.filter_lable.AutoSize = true;
            this.filter_lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.filter_lable.Location = new System.Drawing.Point(24, 156);
            this.filter_lable.Name = "filter_lable";
            this.filter_lable.Size = new System.Drawing.Size(136, 20);
            this.filter_lable.TabIndex = 3;
            this.filter_lable.Text = "Search by Filters";
            // 
            // city_lable
            // 
            this.city_lable.AutoSize = true;
            this.city_lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.city_lable.Location = new System.Drawing.Point(25, 223);
            this.city_lable.Name = "city_lable";
            this.city_lable.Size = new System.Drawing.Size(36, 17);
            this.city_lable.TabIndex = 4;
            this.city_lable.Text = "City*";
            // 
            // stars_lable
            // 
            this.stars_lable.AutoSize = true;
            this.stars_lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.stars_lable.Location = new System.Drawing.Point(25, 252);
            this.stars_lable.Name = "stars_lable";
            this.stars_lable.Size = new System.Drawing.Size(41, 17);
            this.stars_lable.TabIndex = 5;
            this.stars_lable.Text = "Stars";
            // 
            // categoris_lable
            // 
            this.categoris_lable.AutoSize = true;
            this.categoris_lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.categoris_lable.Location = new System.Drawing.Point(25, 194);
            this.categoris_lable.Name = "categoris_lable";
            this.categoris_lable.Size = new System.Drawing.Size(81, 17);
            this.categoris_lable.TabIndex = 6;
            this.categoris_lable.Text = "Catogories*";
            // 
            // postal_code_lable
            // 
            this.postal_code_lable.AutoSize = true;
            this.postal_code_lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.postal_code_lable.Location = new System.Drawing.Point(25, 281);
            this.postal_code_lable.Name = "postal_code_lable";
            this.postal_code_lable.Size = new System.Drawing.Size(84, 17);
            this.postal_code_lable.TabIndex = 7;
            this.postal_code_lable.Text = "Postal Code";
            // 
            // categories_text
            // 
            this.categories_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.categories_text.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.categories_text.Location = new System.Drawing.Point(175, 188);
            this.categories_text.Name = "categories_text";
            this.categories_text.Size = new System.Drawing.Size(115, 23);
            this.categories_text.TabIndex = 8;
            this.categories_text.Text = "Enter category";
            this.categories_text.TextChanged += new System.EventHandler(this.categories_text_TextChanged);
            // 
            // city_text
            // 
            this.city_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.city_text.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.city_text.Location = new System.Drawing.Point(175, 215);
            this.city_text.Name = "city_text";
            this.city_text.Size = new System.Drawing.Size(115, 23);
            this.city_text.TabIndex = 9;
            this.city_text.Text = "Enter city";
            this.city_text.TextChanged += new System.EventHandler(this.city_text_TextChanged);
            // 
            // postal_text
            // 
            this.postal_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.postal_text.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.postal_text.Location = new System.Drawing.Point(175, 275);
            this.postal_text.Name = "postal_text";
            this.postal_text.Size = new System.Drawing.Size(115, 23);
            this.postal_text.TabIndex = 10;
            this.postal_text.Text = "Enter postal code";
            this.postal_text.TextChanged += new System.EventHandler(this.postal_text_TextChanged);
            // 
            // stars_combo
            // 
            this.stars_combo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.stars_combo.FormattingEnabled = true;
            this.stars_combo.Location = new System.Drawing.Point(175, 244);
            this.stars_combo.Name = "stars_combo";
            this.stars_combo.Size = new System.Drawing.Size(115, 25);
            this.stars_combo.TabIndex = 11;
            this.stars_combo.SelectedIndexChanged += new System.EventHandler(this.stars_combo_SelectedIndexChanged);
            // 
            // reset_button
            // 
            this.reset_button.Location = new System.Drawing.Point(154, 314);
            this.reset_button.Name = "reset_button";
            this.reset_button.Size = new System.Drawing.Size(66, 33);
            this.reset_button.TabIndex = 12;
            this.reset_button.Text = "Reset";
            this.reset_button.UseVisualStyleBackColor = true;
            this.reset_button.Click += new System.EventHandler(this.reset_button_Click);
            // 
            // apply_button
            // 
            this.apply_button.Location = new System.Drawing.Point(57, 314);
            this.apply_button.Name = "apply_button";
            this.apply_button.Size = new System.Drawing.Size(72, 33);
            this.apply_button.TabIndex = 13;
            this.apply_button.Text = "Apply";
            this.apply_button.UseVisualStyleBackColor = true;
            this.apply_button.Click += new System.EventHandler(this.apply_button_Click);
            // 
            // result_grid
            // 
            this.result_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.result_grid.Location = new System.Drawing.Point(402, 53);
            this.result_grid.Name = "result_grid";
            this.result_grid.Size = new System.Drawing.Size(546, 357);
            this.result_grid.TabIndex = 14;
            // 
            // result_lable
            // 
            this.result_lable.AutoSize = true;
            this.result_lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.result_lable.Location = new System.Drawing.Point(655, 19);
            this.result_lable.Name = "result_lable";
            this.result_lable.Size = new System.Drawing.Size(57, 20);
            this.result_lable.TabIndex = 15;
            this.result_lable.Text = "Result";
            // 
            // Query
            // 
            this.Query.AutoSize = true;
            this.Query.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.Query.Location = new System.Drawing.Point(398, 425);
            this.Query.Name = "Query";
            this.Query.Size = new System.Drawing.Size(54, 20);
            this.Query.TabIndex = 16;
            this.Query.Text = "Query";
            // 
            // QueryTextBox
            // 
            this.QueryTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.QueryTextBox.Location = new System.Drawing.Point(458, 425);
            this.QueryTextBox.Multiline = true;
            this.QueryTextBox.Name = "QueryTextBox";
            this.QueryTextBox.Size = new System.Drawing.Size(490, 89);
            this.QueryTextBox.TabIndex = 17;
            this.QueryTextBox.TextChanged += new System.EventHandler(this.QueryTextBox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label2.Location = new System.Drawing.Point(12, 390);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Complex Queries";
            // 
            // Top_Users
            // 
            this.Top_Users.Location = new System.Drawing.Point(12, 496);
            this.Top_Users.Name = "Top_Users";
            this.Top_Users.Size = new System.Drawing.Size(72, 33);
            this.Top_Users.TabIndex = 19;
            this.Top_Users.Text = "Top Users";
            this.Top_Users.UseVisualStyleBackColor = true;
            this.Top_Users.Click += new System.EventHandler(this.Top_Users_Click);
            // 
            // Go1button
            // 
            this.Go1button.Location = new System.Drawing.Point(296, 423);
            this.Go1button.Name = "Go1button";
            this.Go1button.Size = new System.Drawing.Size(32, 26);
            this.Go1button.TabIndex = 20;
            this.Go1button.Text = "Go";
            this.Go1button.UseVisualStyleBackColor = true;
            this.Go1button.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label3.Location = new System.Drawing.Point(145, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 17);
            this.label3.TabIndex = 23;
            this.label3.Text = "OR";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // postalText
            // 
            this.postalText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.postalText.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.postalText.Location = new System.Drawing.Point(175, 424);
            this.postalText.Name = "postalText";
            this.postalText.Size = new System.Drawing.Size(115, 23);
            this.postalText.TabIndex = 25;
            this.postalText.Text = "Enter postal code";
            this.postalText.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Deliverlable
            // 
            this.Deliverlable.AutoSize = true;
            this.Deliverlable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.Deliverlable.Location = new System.Drawing.Point(12, 427);
            this.Deliverlable.Name = "Deliverlable";
            this.Deliverlable.Size = new System.Drawing.Size(143, 17);
            this.Deliverlable.TabIndex = 24;
            this.Deliverlable.Text = "Want food delivered?";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.textBox1.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.textBox1.Location = new System.Drawing.Point(221, 458);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(115, 23);
            this.textBox1.TabIndex = 28;
            this.textBox1.Text = "Enter category";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.Location = new System.Drawing.Point(12, 461);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 17);
            this.label4.TabIndex = 27;
            this.label4.Text = "Report on Sunday open hours:";
            // 
            // report_button
            // 
            this.report_button.Location = new System.Drawing.Point(342, 457);
            this.report_button.Name = "report_button";
            this.report_button.Size = new System.Drawing.Size(32, 26);
            this.report_button.TabIndex = 26;
            this.report_button.Text = "Go";
            this.report_button.UseVisualStyleBackColor = true;
            this.report_button.Click += new System.EventHandler(this.report_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Business.Properties.Resources.sea_edge_79ab30e2;
            this.ClientSize = new System.Drawing.Size(960, 565);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.report_button);
            this.Controls.Add(this.postalText);
            this.Controls.Add(this.Deliverlable);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Go1button);
            this.Controls.Add(this.Top_Users);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.QueryTextBox);
            this.Controls.Add(this.Query);
            this.Controls.Add(this.result_lable);
            this.Controls.Add(this.result_grid);
            this.Controls.Add(this.apply_button);
            this.Controls.Add(this.reset_button);
            this.Controls.Add(this.stars_combo);
            this.Controls.Add(this.postal_text);
            this.Controls.Add(this.city_text);
            this.Controls.Add(this.categories_text);
            this.Controls.Add(this.postal_code_lable);
            this.Controls.Add(this.categoris_lable);
            this.Controls.Add(this.stars_lable);
            this.Controls.Add(this.city_lable);
            this.Controls.Add(this.filter_lable);
            this.Controls.Add(this.Go_button);
            this.Controls.Add(this.NameSearchText);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "YELP DATASET";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.result_grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NameSearchText;
        private System.Windows.Forms.Button Go_button;
        private System.Windows.Forms.Label filter_lable;
        private System.Windows.Forms.Label city_lable;
        private System.Windows.Forms.Label stars_lable;
        private System.Windows.Forms.Label categoris_lable;
        private System.Windows.Forms.Label postal_code_lable;
        private System.Windows.Forms.TextBox categories_text;
        private System.Windows.Forms.TextBox city_text;
        private System.Windows.Forms.TextBox postal_text;
        private System.Windows.Forms.ComboBox stars_combo;
        private System.Windows.Forms.Button reset_button;
        private System.Windows.Forms.Button apply_button;
        private System.Windows.Forms.DataGridView result_grid;
        private System.Windows.Forms.Label result_lable;
        private System.Windows.Forms.Label Query;
        private System.Windows.Forms.TextBox QueryTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Top_Users;
        private System.Windows.Forms.Button Go1button;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox postalText;
        private System.Windows.Forms.Label Deliverlable;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button report_button;
    }
}

