﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Business
{
   
    public partial class Form1 : Form
    {
        public static class Global
        {
            public static int star_flag = 0;
            public static int postal_flag = 0;
            public static int categories_flag = 0;
            public static int city_flag = 0;
            public static float star_val = 1.0F;
        }
        public Form1()
        {
            InitializeComponent();
            this.stars_combo.Items.AddRange(new object[] { "1 and above", "2 and above", "3 and above",
                "4 and above", "5 and above" });
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Go_button_Click(object sender, EventArgs e)
        {
            string query = "select name,address,stars  from business where name like '%" + this.NameSearchText .Text + "%';";

            try
            {
                String conn;
                MySqlConnection sq;

                conn = "server=localhost;user id=root;persistsecurityinfo=True;database=yelp;password=mugu1606";
                sq = new MySqlConnection(conn);

                sq.Open();
                MySqlCommand mycommand = new MySqlCommand(query, sq);

                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = mycommand;
                DataTable table = new DataTable();
                adapter.Fill(table);
                this.result_grid.DataSource = table;
                this.QueryTextBox.Text = query;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }

        private void NameSearchText_TextChanged(object sender, EventArgs e)
        {
            if (this.NameSearchText.Text== "Enter business name")
            {
                this.NameSearchText.Text = string.Empty;
                this.NameSearchText.ForeColor = Color.Black;
            }

        }

        private void reset_button_Click(object sender, EventArgs e)
        {
            this.categories_text.Text = string.Empty;
            this.city_text.Text = string.Empty;
            this.postal_text.Text = string.Empty;
            this.stars_combo.ResetText();
            this.result_grid.DataSource= null;
            this.result_grid.Refresh();
            this.QueryTextBox.Text = string.Empty;

        }

        private void apply_button_Click(object sender, EventArgs e)
        {
            if (Global.categories_flag==0 || Global.city_flag==0) {
                MessageBox.Show("Enter the mandatory filters marked by ' * '");
;            }
            if (Global.categories_flag == 1 & Global.city_flag == 1 & Global.postal_flag == 0 & Global.star_flag == 0) {

                
                string query = "select distinct b.name, b.address,b.city, b.stars  from business as b, categories as c where b.business_id =c.business_id and " +
                    "b.city like '%" + this.city_text.Text + "%' and c.categories like '%" + this.categories_text.Text + "%' limit 20;";

                try
                {
                    String conn;
                    MySqlConnection sq;

                    conn = "server=localhost;user id=root;persistsecurityinfo=True;database=yelp;password=mugu1606";
                    sq = new MySqlConnection(conn);

                    sq.Open();
                    

                    MySqlCommand mycommand = new MySqlCommand(query, sq);

                    MySqlDataAdapter adapter = new MySqlDataAdapter();
                    adapter.SelectCommand = mycommand;
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    this.result_grid.DataSource = table;
                    this.QueryTextBox.Text = query;
               

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
            else if (Global.categories_flag == 1 & Global.city_flag == 1 & Global.postal_flag == 1 & Global.star_flag == 0)
            {
                string query = "select distinct b.name, b.address,b.city, b.stars  from business as b, categories as c where " +
                    "b.business_id =c.business_id and " + "b.city like '%" + this.city_text.Text + "%' and c.categories " +
                    "like '%" + this.categories_text.Text + "%' and b.postal_code='" + this.postal_text.Text +"' limit 20; ";

                try
                {
                    String conn;
                    MySqlConnection sq;

                    conn = "server=localhost;user id=root;persistsecurityinfo=True;database=yelp;password=mugu1606";
                    sq = new MySqlConnection(conn);

                    sq.Open();
                    MySqlCommand mycommand = new MySqlCommand(query, sq);

                    MySqlDataAdapter adapter = new MySqlDataAdapter();
                    adapter.SelectCommand = mycommand;
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    this.result_grid.DataSource = table;
                    this.QueryTextBox.Text = query;


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
            else if (Global.categories_flag == 1 & Global.city_flag == 1 & Global.postal_flag == 0 & Global.star_flag == 1)
            {
                string query = "select distinct b.name, b.address,b.city, b.stars  from business as b, categories as c where" +
                    " b.business_id =c.business_id and " +"b.city like '%" + this.city_text.Text + "%' and c.categories like '%" 
                    + this.categories_text.Text +"%' and b.stars >="+ Global.star_val+ "; ";

                try
                {
                    String conn;
                    MySqlConnection sq;

                    conn = "server=localhost;user id=root;persistsecurityinfo=True;database=yelp;password=mugu1606";
                    sq = new MySqlConnection(conn);

                    sq.Open();
                    MySqlCommand mycommand = new MySqlCommand(query, sq);

                    MySqlDataAdapter adapter = new MySqlDataAdapter();
                    adapter.SelectCommand = mycommand;
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    this.result_grid.DataSource = table;
                    this.QueryTextBox.Text = query;


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
            else if (Global.categories_flag == 1 & Global.city_flag == 1 & Global.postal_flag == 1 & Global.star_flag == 1)
            {
                string query = "select distinct b.name, b.address,b.city, b.stars from business as b, categories as c where" +
                    " b.business_id =c.business_id and " + "b.city like '%" + this.city_text.Text + "%' and c.categories like '%" +
                    this.categories_text.Text + "%' and b.stars >=" + Global.star_val +" and b.postal_code='"+ this.postal_text.Text + "' ; ";

                try
                {
                    String conn;
                    MySqlConnection sq;

                    conn = "server=localhost;user id=root;persistsecurityinfo=True;database=yelp;password=mugu1606";
                    sq = new MySqlConnection(conn);

                    sq.Open();
                    MySqlCommand mycommand = new MySqlCommand(query, sq);

                    MySqlDataAdapter adapter = new MySqlDataAdapter();
                    adapter.SelectCommand = mycommand;
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    this.result_grid.DataSource = table;
                    this.QueryTextBox.Text = query;


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }

        }

        private void categories_text_TextChanged(object sender, EventArgs e)
        {

            if (this.categories_text.Text == "Enter category")
            {
                this.categories_text.Text = string.Empty;
                this.categories_text.ForeColor = Color.Black;
            }
            Global.categories_flag = 1;

        }

        private void city_text_TextChanged(object sender, EventArgs e)
        {

            if (this.city_text.Text == "Enter city")
            {
                this.city_text.Text = string.Empty;
                this.city_text.ForeColor = Color.Black;
            }
            Global.city_flag = 1;
        }

        private void stars_combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            Global.star_flag = 1;

            string selected = stars_combo.SelectedItem.ToString();

            if (selected.Equals("1 and above"))
            {
                Global.star_val = 1;
            }
            else if (selected.Equals("2 and above"))
            {
                Global.star_val = 2;
            }
            else if (selected.Equals("3 and above"))
            {
                Global.star_val = 3;
            }
            else if (selected.Equals("4 and above"))
            {
                Global.star_val = 4;
            }
        }

        private void postal_text_TextChanged(object sender, EventArgs e)
        {
            Global.postal_flag = 1;

            if (this.postal_text.Text == "Enter postal code")
            {
                this.postal_text.Text = string.Empty;
                this.postal_text.ForeColor = Color.Black;
            }
        }

        private void QueryTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Top_Users_Click(object sender, EventArgs e)
        {
            string query = "select u.name as User_name,u.average_stars as User_rating from user as u where u.yelping_since > 365 and review_count> 500 and exists" +
                "(select user_id from review as r  where r.user_id= u.user_id and r.useful>= 10) order by u.average_stars desc;";

            try
            {
                String conn;
                MySqlConnection sq;

                conn = "server=localhost;user id=root;persistsecurityinfo=True;database=yelp;password=mugu1606";
                sq = new MySqlConnection(conn);

                sq.Open();
                MySqlCommand mycommand = new MySqlCommand(query, sq);

                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = mycommand;
                DataTable table = new DataTable();
                adapter.Fill(table);
                this.result_grid.DataSource = table;
                this.QueryTextBox.Text = query;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "select distinct b.name,b.address, b.stars from business as b, attributes as a, categories as c " +
                "where b.business_id = a.business_id and b.business_id = c.business_id and b.postal_code ='"+ this.postalText.Text  +"' and a.restaurantsdelivery = 'true' " +
                "and (c.categories like '%food%' or c.categories like '%restaurant%') order by b.stars desc; ";

            try
            {
                String conn;
                MySqlConnection sq;

                conn = "server=localhost;user id=root;persistsecurityinfo=True;database=yelp;password=mugu1606";
                sq = new MySqlConnection(conn);

                sq.Open();
                MySqlCommand mycommand = new MySqlCommand(query, sq);

                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = mycommand;
                DataTable table = new DataTable();
                adapter.Fill(table);
                this.result_grid.DataSource = table;
                this.QueryTextBox.Text = query;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (this.postalText.Text == "Enter postal code")
            {
                this.postalText.Text = string.Empty;
                this.postalText.ForeColor = Color.Black;
            }
        }

        private void report_button_Click(object sender, EventArgs e)
        {
            string query = "select b.city as City, count(b.business_id) as business_count, round(avg(b.stars),1) as rating from business b, hours h" +
                            " where b.business_id in (select distinct c.business_id from categories as c where c.categories like '%" + this.textBox1.Text + "%')" +
                            " and b.business_id = h.business_id" +
                            " and(h.sunday not like '%0:0-0:0%' and h.sunday is not null) group by City order by business_count desc; ";


            try
            {
                String conn;
                MySqlConnection sq;

                conn = "server=localhost;user id=root;persistsecurityinfo=True;database=yelp;password=mugu1606";
                sq = new MySqlConnection(conn);

                sq.Open();
                MySqlCommand mycommand = new MySqlCommand(query, sq);

                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = mycommand;
                DataTable table = new DataTable();
                adapter.Fill(table);
                this.result_grid.DataSource = table;
                this.QueryTextBox.Text = query;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            if (this.textBox1.Text == "Enter category")
            {
                this.textBox1.Text = string.Empty;
                this.textBox1.ForeColor = Color.Black;
            }
        }
    }
}
